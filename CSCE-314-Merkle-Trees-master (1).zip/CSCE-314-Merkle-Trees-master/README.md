# CSCE-314-Merkle-Trees
Add all files to an eclipse Java Project and run the driver under the package name "MainPackage".
Output of MerkleTree should be an array list containing the hashed values of each node in the perfect binary tree.
